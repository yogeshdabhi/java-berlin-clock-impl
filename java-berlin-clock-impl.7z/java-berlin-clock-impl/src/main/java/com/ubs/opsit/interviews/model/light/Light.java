package com.ubs.opsit.interviews.model.light;

/**
 * The Interface Light.
 */
public interface Light {

	/**
	 * Swtich on.
	 */
	public void swtichOn();

	/**
	 * Swtich off.
	 */
	public void swtichOff();

}
